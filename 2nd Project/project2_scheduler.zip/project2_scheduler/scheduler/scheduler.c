/* ΘΕΟΔΩΡΟΣ ΚΑΤΣΑΝΤΑΣ ΑΜ1097459
        up1097459@ac.upatras.gr
ΑΓΓΕΛΙΚΗ ΔΟΥΒΡΗ ΑΜ1097441
        up1097441@ac.upatras.gr
ΑΓΑΠΗ ΑΥΓΟΥΣΤΙΝΟΥ ΑΜ1093327
        up1093327@ac.upatras.gr
*/




#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <sys/time.h>


enum ProcessState {
    NEW,
    RUNNING,
    STOPPED,
    EXITED
};

// Definition of the process structure
struct Process {
    char name[20];
    int pid;
    enum ProcessState state;
    time_t entry_time;
    time_t start_time;  // Track process start time
    time_t end_time;    // Track process end time
};

struct Node {
    struct Process data;
    struct Node* next;
    struct Node* prev; // Add a previous pointer
};

// Definition of the queue structure
struct Queue {
    struct Node* front;
    struct Node* rear;
};

void enqueue(struct Queue* queue, struct Process process) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        perror("Error creating new node");
        exit(EXIT_FAILURE);
    }
    newNode->data = process;
    newNode->next = NULL;

    if (queue->rear == NULL) {
        newNode->prev = NULL;
        queue->front = queue->rear = newNode;
    } else {
        newNode->prev = queue->rear;
        queue->rear->next = newNode;
        queue->rear = newNode;
    }
}


struct Process dequeue(struct Queue* queue) {
    if (queue->front == NULL) {
        fprintf(stderr, "Queue is empty\n");
        exit(EXIT_FAILURE);
    }

    struct Process process = queue->front->data;
    struct Node* temp = queue->front;

    queue->front = queue->front->next;

    if (queue->front == NULL) {
        queue->rear = NULL;
    } else {
        queue->front->prev = NULL;
    }

    free(temp);
    return process;
}


// Checking if the queue is empty
int is_empty(struct Queue* queue) {
    return queue->front == NULL;
}

// Returning the first element in the queue without removing it
struct Process peek(struct Queue* queue) {
    if (queue->front == NULL) {
        fprintf(stderr, "Queue is empty\n");
        exit(EXIT_FAILURE);
    }
    return queue->front->data;
}



void handle_child_termination(int signum) {
    if (signum == SIGCHLD) {
        int status;
        pid_t child_pid;
        while ((child_pid = waitpid(-1, &status, WNOHANG)) > 0) {
            printf("Child process with PID %d has terminated.\n", child_pid);
            // Update process information as needed, e.g., set EXITED state
        }
    }
}

typedef struct {
    int pid;
    int is_executed;
} ExecutedProcess;

typedef struct {
    ExecutedProcess* data[100];
    int size;
} ExecutedProcessSet;

void init_executed_process_set(ExecutedProcessSet* set) {
    set->size = 0;
}

int is_executed(ExecutedProcessSet* set, int pid) {
    for (int i = 0; i < set->size; i++) {
        if (set->data[i]->pid == pid) {
            return set->data[i]->is_executed;
        }
    }
    return 0;
}

void add_executed_process(ExecutedProcessSet* set, int pid) {
    for (int i = 0; i < set->size; i++) {
        if (set->data[i]->pid == pid) {
            set->data[i]->is_executed = 1;
            return;
        }
    }

    ExecutedProcess* newProcess = (ExecutedProcess*)malloc(sizeof(ExecutedProcess));
    if (newProcess == NULL) {
        perror("Error allocating memory for ExecutedProcess");
        exit(EXIT_FAILURE);
    }

    newProcess->pid = pid;
    newProcess->is_executed = 1;

    set->data[set->size++] = newProcess;
}

// Definition of the function for the main FCFS scheduler
void run_fcfs(struct Queue* queue) {
    while (!is_empty(queue)) {
        struct Process process = dequeue(queue);
        process.state = RUNNING;
        process.entry_time = time(NULL);
        process.start_time = process.entry_time; // Record start time

        printf("Executing process: %s (PID: %d)\n", process.name, process.pid);

        pid_t child_pid = fork();

        if (child_pid == -1) {
            perror("Error forking process");
            exit(EXIT_FAILURE);
        } else if (child_pid == 0) {
            execlp(process.name, process.name, NULL);
            perror("Error executing process");
            exit(EXIT_FAILURE);
        } else {
            int status;
            waitpid(child_pid, &status, 0);
            process.state = EXITED;
            process.end_time = time(NULL); // Record end time
            printf("Process %s (PID: %d) has exited.\n", process.name, process.pid);
            printf("Total execution time: %ld seconds\n", process.end_time - process.start_time);
        }
    }
}

int process_stopped = 0;

void handle_stop_continue(int signum) {
    if (signum == SIGALRM) {
        printf("Received SIGALRM signal.\n");
        process_stopped = 1;
    } else if (signum == SIGCONT) {
        printf("Received SIGCONT signal.\n");
        process_stopped = 0;
    }
}

void run_rr(struct Queue* queue, int time_quantum) {
    while (!is_empty(queue)) {
        ExecutedProcessSet executedProcesses;
        init_executed_process_set(&executedProcesses);

        struct Process process = dequeue(queue);

        // Execute the process for the specified time quantum
        process.state = RUNNING;
        process.entry_time = time(NULL);
        process.start_time = process.entry_time;

        printf("Executing process: %s (PID: %d)\n", process.name, process.pid);

        int status;
        pid_t child_pid = fork();

        if (child_pid == -1) {
            perror("Error forking process");
            exit(EXIT_FAILURE);
        } else if (child_pid == 0) {
            execlp(process.name, process.name, NULL);
            perror("Error executing process");
            exit(EXIT_FAILURE);
        } else {
            // Sleep for the specified time quantum
            sleep(time_quantum / 1000);

            // Send a STOP signal to the current process to pause
            kill(child_pid, SIGSTOP);

            // Add the process to the executed set
            add_executed_process(&executedProcesses, process.pid);

            // Check if there are any other processes in the queue
            if (!is_empty(queue)) {
                // Dequeue the next process
                struct Process nextProcess = dequeue(queue);

                // Start executing the next process
                nextProcess.state = RUNNING;

                printf("Executing process: %s (PID: %d)\n", nextProcess.name, nextProcess.pid);

                // Fork and execute the next process
                pid_t nextChild_pid = fork();

                if (nextChild_pid == -1) {
                    perror("Error forking process");
                    exit(EXIT_FAILURE);
                } else if (nextChild_pid == 0) {
                    execlp(nextProcess.name, nextProcess.name, NULL);
                    perror("Error executing process");
                    exit(EXIT_FAILURE);
                } else {
                    // Wait for the next process to finish
                    waitpid(nextChild_pid, &status, 0);
                    nextProcess.state = EXITED;
                }
            }

            // Send a CONT signal to the current process to resume
            kill(child_pid, SIGCONT);
        }
    }
}



int main(int argc, char *argv[]) {
    if (argc < 3 || argc > 4) {
        fprintf(stderr, "Usage: %s <policy> [<quantum>] <input_filename>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *policy = argv[1];
    char *input_filename = argv[argc - 1];

    struct Queue processQueue = { .front = NULL, .rear = NULL };

    FILE *inputFile = fopen(input_filename, "r");
    if (inputFile == NULL) {
        perror("Error opening input file");
        exit(EXIT_FAILURE);
    }

    struct Process process;
    int uniqueID = 1;

    while (fscanf(inputFile, "%s", process.name) == 1) {
        process.pid = uniqueID++;
        enqueue(&processQueue, process);
    }

    fclose(inputFile);

    // Set up signal handlers
    signal(SIGSTOP, handle_stop_continue);
    signal(SIGCONT, handle_stop_continue);
    signal(SIGCHLD, handle_child_termination);

    printf("Running Scheduler with Policy: %s\n", policy);

    if (strcmp(policy, "FCFS") == 0) {
        run_fcfs(&processQueue);
    } else if (strcmp(policy, "RR") == 0) {
        if (argc != 4) {
            fprintf(stderr, "Usage for RR policy: %s RR <quantum> <input_filename>\n", argv[0]);
            exit(EXIT_FAILURE);
        }

        int time_quantum = atoi(argv[2]);
        run_rr(&processQueue, time_quantum);
    } else {
        fprintf(stderr, "Invalid policy. Supported policies: FCFS, RR\n");
        exit(EXIT_FAILURE);
    }

    // Reset signal handlers (optional)
    signal(SIGSTOP, SIG_DFL);
    signal(SIGCONT, SIG_DFL);
    signal(SIGCHLD, SIG_DFL);

    return 0;
}
