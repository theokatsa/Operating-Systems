/*ΘΕΟΔΩΡΟΣ ΚΑΤΣΑΝΤΑΣ ΑΜ1097459
        up1097459@ac.upatras.gr
ΑΓΓΕΛΙΚΗ ΔΟΥΒΡΗ ΑΜ1097441
        up1097441@ac.upatras.gr
ΑΓΑΠΗ ΑΥΓΟΥΣΤΙΝΟΥ ΑΜ1093327
        up1093327@ac.upatras.gr
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>
#include <string.h>

// Define the process structure
struct Process {
    char name[20];
    int pid;
    enum ProcessState {
        NEW,
        RUNNING,
        STOPPED,
        EXITED
    } state;
    time_t entry_time;
    time_t start_time;  // Track process start time
    time_t end_time;    // Track process end time
};

// Define the node structure for the linked list
struct Node {
    struct Process data;
    struct Node* next;
    struct Node* prev;
};

// Define the queue structure
struct Queue {
    struct Node* front;
    struct Node* rear;
};

// Function to handle the alarm signal
void alarm_handler(int signum) {
    // Do nothing; this is used to interrupt the usleep in the main loop
}

// Define the function signature for I/O handling
void perform_io(int ms) {
    struct sigaction sa;
    sa.sa_handler = SIG_IGN;  // Ignore signals during I/O
    sa.sa_flags = 0;
    sigaction(SIGUSR1, &sa, NULL);
    sigaction(SIGUSR2, &sa, NULL);

    usleep(ms * 1000);

    sa.sa_handler = SIG_DFL;  // Restore default behavior after I/O
    sigaction(SIGUSR1, &sa, NULL);
    sigaction(SIGUSR2, &sa, NULL);

    // Ensure the child process exits successfully
    exit(EXIT_SUCCESS);
}

// Enqueue a process into the queue
void enqueue(struct Queue* queue, struct Process process) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        perror("Error creating new node");
        exit(EXIT_FAILURE);
    }
    newNode->data = process;
    newNode->next = NULL;

    if (queue->rear == NULL) {
        newNode->prev = NULL;
        queue->front = queue->rear = newNode;
    } else {
        newNode->prev = queue->rear;
        queue->rear->next = newNode;
        queue->rear = newNode;
    }
}

// Dequeue a process from the queue
struct Process dequeue(struct Queue* queue) {
    if (queue->front == NULL) {
        fprintf(stderr, "Queue is empty\n");
        exit(EXIT_FAILURE);
    }

    struct Process process = queue->front->data;
    struct Node* temp = queue->front;

    queue->front = queue->front->next;

    if (queue->front == NULL) {
        queue->rear = NULL;
    } else {
        queue->front->prev = NULL;
    }

    free(temp);
    return process;
}

// Check if the queue is empty
int is_empty(struct Queue* queue) {
    return queue->front == NULL;
}

// Peek at the front of the queue
struct Process peek(struct Queue* queue) {
    if (queue->front == NULL) {
        fprintf(stderr, "Queue is empty\n");
        exit(EXIT_FAILURE);
    }
    return queue->front->data;
}

void run_fcfs(struct Queue* queue) {
    while (!is_empty(queue)) {
        struct Process process = dequeue(queue);
        process.state = RUNNING;
        process.entry_time = time(NULL);
        process.start_time = process.entry_time;

        printf("Executing process: %s (PID: %d)\n", process.name, process.pid);

        pid_t child_pid = fork();

        if (child_pid == -1) {
            perror("Error forking process");
            exit(EXIT_FAILURE);
        } else if (child_pid == 0) {
            // Child process
            signal(SIGUSR1, perform_io);
            signal(SIGUSR2, perform_io);

            perform_io(5000);
            exit(EXIT_SUCCESS);
        } else {
            // Parent process
            int status;
            waitpid(child_pid, &status, 0);

            if (WIFEXITED(status) || WIFSIGNALED(status)) {
                process.state = EXITED;
                printf("Process %s (PID: %d) has exited.\n", process.name, process.pid);
            } else {
                perror("Child process did not exit successfully");
                exit(EXIT_FAILURE);
            }

            // Reset signal handlers outside the loop
            signal(SIGUSR1, SIG_DFL);
            signal(SIGUSR2, SIG_DFL);
        }
    }
}

// Signal handler for SIGUSR2
void child_complete_handler(int signum) {
    // Do nothing; this is just used to interrupt the pause() in the parent process
}

void run_rr(struct Queue* queue, int time_quantum) {
    while (!is_empty(queue)) {
        struct Process process = dequeue(queue);
        process.state = RUNNING;
        process.entry_time = time(NULL);
        process.start_time = process.entry_time;

        printf("Executing process: %s (PID: %d)\n", process.name, process.pid);

        pid_t child_pid = fork();

        if (child_pid == -1) {
            perror("Error forking process");
            exit(EXIT_FAILURE);
        } else if (child_pid == 0) {
            // Child process
            signal(SIGUSR1, perform_io);
            signal(SIGUSR2, perform_io);

            while (1) {
                // Perform I/O
                usleep(5000 * 1000);

                // Send signal to parent to notify completion of I/O
                kill(getppid(), SIGUSR2);
            }
        } else {
            // Parent process
            struct sigaction sa;
            sa.sa_handler = SIG_IGN;  // Ignore signals during the sleep period
            sa.sa_flags = 0;
            sigaction(SIGCONT, &sa, NULL);
            sigaction(SIGCHLD, &sa, NULL);

            // Set up alarm to handle time quantum
            signal(SIGALRM, alarm_handler);
            alarm(time_quantum / 1000);  // Convert milliseconds to seconds

            // Set up signal handler for SIGUSR2 to catch child completion of I/O
            sa.sa_handler = child_complete_handler;
            sa.sa_flags = 0;
            sigaction(SIGUSR2, &sa, NULL);

            // Wait for the child process to stop or the alarm to interrupt
            int status;
            waitpid(child_pid, &status, WUNTRACED);

            // Cancel the alarm
            alarm(0);

            if (WIFEXITED(status) || WIFSIGNALED(status)) {
                process.state = EXITED;
                process.end_time = time(NULL);
                printf("Process %s (PID: %d) has exited.\n", process.name, process.pid);
                printf("Total execution time: %lld milliseconds\n", (long long int)(process.end_time - process.start_time) * 1000);
            } else {
                perror("Child process did not exit successfully");
                exit(EXIT_FAILURE);
            }

            // Reset signal handlers
            sa.sa_handler = SIG_DFL;
            sa.sa_flags = 0;
            sigaction(SIGCONT, &sa, NULL);
            sigaction(SIGCHLD, &sa, NULL);
        }
    }
}


int main(int argc, char* argv[]) {
    if (argc < 3 || argc > 4) {
        fprintf(stderr, "Usage: %s <policy> [<quantum>] <input_filename>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char* policy = argv[1];
    char* input_filename = argv[argc - 1];

    struct Queue processQueue = {.front = NULL, .rear = NULL};

    FILE* inputFile = fopen(input_filename, "r");
    if (inputFile == NULL) {
        perror("Error opening input file");
        exit(EXIT_FAILURE);
    }

    struct Process process;
    int uniqueID = 1;

    while (fscanf(inputFile, "%s", process.name) == 1) {
        process.pid = uniqueID++;
        enqueue(&processQueue, process);
    }

    fclose(inputFile);

    printf("Running Scheduler with Policy: %s\n", policy);

    if (strcmp(policy, "FCFS") == 0) {
        run_fcfs(&processQueue);
    } else if (strcmp(policy, "RR") == 0) {
        if (argc != 4) {
            fprintf(stderr, "Usage for RR policy: %s RR <quantum> <input_filename>\n", argv[0]);
            exit(EXIT_FAILURE);
        }

        int time_quantum = atoi(argv[2]);
        run_rr(&processQueue, time_quantum);
    } else {
        fprintf(stderr, "Invalid policy. Supported policies: FCFS, RR\n");
        exit(EXIT_FAILURE);
    }

    sleep(5);

    return 0;
}
